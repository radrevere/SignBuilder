Required packages:
npm install express
npm install mysql
npm install babel-cli babel-core babel-preset

/src - jsx file for the app
/js - babel-translated output of the jsx
/appjs - server-side code for rendering an SVG for display based on the JSON object the app builds
signserver.js - Node.js server endpoints and calls to appjs